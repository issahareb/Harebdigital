# Lighthouse-Messreihe · 16. Oktober 2026

24 erfolgreiche Läufe: zwei Websites, zwei Geräteprofile, jeweils drei Läufe vor und nach der Optimierung. Die JSON-Dateien sind unveränderte Lighthouse-Berichte. SHA-256-Prüfsummen, Zeitstempel, Einzelwerte, Median und Spannweite stehen in summary.json.

Methode: Lighthouse 13.5.0, Chromium Headless 134.0.6998.35, Standardprofile Mobile und Desktop, simulierte Drosselung, je Lauf ein frisches Browserprofil. Alle Läufe nacheinander, ohne parallele Builds oder Browserprüfungen. Beide Messreihen laufen aus derselben Cloud-Arbeitsumgebung über deren Netzwerkproxy. Zertifikatsprüfung des Audit-Browsers für diesen Proxy deaktiviert. Keine benutzerdefinierten Header, keine angemeldete Sitzung. Die exakten Drosselungs- und Bildschirmparameter sind in summary.json und jedem Bericht enthalten.

Labormessungen hängen von Gerät, Netzwerk, Testversion und Serverantwort ab. Der Proxy beeinflusst die Netzwerkbeobachtung. Die Ergebnisse sind deshalb innerhalb dieser Serie vergleichbar, aber nicht ohne Weiteres mit PageSpeed Insights oder früheren, anders durchgeführten Tests. Sie sind keine repräsentativen Besucherdaten. TBT ist kein gemessener INP. Es werden keine Buchungs- oder Umsatzsteigerungen und keine Überlegenheit gegenüber anderen Websites abgeleitet.

Vorher/Nachher bezeichnet nur diese Optimierungsrunde, nicht den ursprünglichen Website-Relaunch. Die zuvor genannten Werte 63, 72 oder 94 stammen aus anderen Messungen und gehen nicht in diese Serie ein. Der zugeschickte Konkurrenzvergleich wird mangels prüfbarer Rohdaten nicht veröffentlicht.

Wiederholung: Lighthouse CLI in Version 13.5.0 installieren, CHROME_PATH auf dieselbe Chromium-Version setzen. Je Website drei Aufrufe mit --only-categories=performance,accessibility,best-practices,seo --output=json; für Desktop zusätzlich --preset=desktop. Für identische Netzwerkbedingungen ist dieselbe Proxy-Umgebung erforderlich. Rohberichte als taxi-before-mobile-1.json usw. speichern. Auswertung: python scripts/summarize-lighthouse-series.py <Berichtsordner>.

Quellrevisionen und alle Messzeitpunkte stehen in summary.json. Die Änderung des Fallstudientextes nach der Messung verändert die untersuchten Startseiten nicht.
